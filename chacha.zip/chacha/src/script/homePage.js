$(function() { 
    (function($){

       function HomePage () {
          this.init();
       }
       HomePage.prototype  = {
          constructor:HomePage,
          init:function(){
              this.GotoGame();
              this.activity();
          },
          activity : function(){
                $(".homePage_activity").tap(function(){
                    common.isShowPop($(".activityRules"),true);

                    $(".activityRules_btn").tap(function (argument) {
                      common.isShowPop($(".activityRules"),false);  
                    })
                })

          },
          GotoGame:function(){
              $(".homePage_start").tap(function(){

              })
          }
          
       };
       var home_Page = new HomePage();
    })($)

});