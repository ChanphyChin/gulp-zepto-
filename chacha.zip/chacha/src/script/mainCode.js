$(function() { 
(function($){
    function mainCode(){
        this.$xiguaBox=$("#xigua");
        this.timerNumber = 10;
        //this.$xigua = $("#xigua > div");
        this.init();

    };
    mainCode.prototype = {
       
        constructor:mainCode,
       
        /**
         *  初始化
         * @return {[type]} [description]
         */
         init:function(){
            
            // this.CreationWatermelon();
            this.timer();
            this.daxigua();
            this.ChaCha();
            this.theWinning();

           
        },
        "class_game":{
             "$column" : 5, //西瓜的排列的列
             "$row" : 3,    // 西瓜的排列的行
             "$divWidth": parseInt($("#xigua").width())/ 5, //分布的宽度
             "$divHeight":parseInt($("#xigua").height())    //分布的高度
        },
         /**
         * 创建随机大小的西瓜与排列西瓜的位置
         * @param {[type]} obj [description]
         */
        CreationWatermelon:function(obj){
            var  $Size = parseInt(this.getFontSize());
            var class_game = this.class_game;
            var $xiguaBox = $("#xigua");
            // 随机的图
            var src = ['/image/xigua2.png','/image/xigua.png'];
       
          for(var $x =0,length_1 = class_game.$column; $x < length_1;$x++){
            for(var $y=0,length_2 = class_game.$row;$y< length_2;$y++){
                var $imgWidth = 70;
                // var $width = "";
                //设计随机的宽度与偏移的值
                var $rotate = Math.floor(360 * Math.random());
                // (Math.random()*10+ -10)
                var left = (class_game.$divWidth*$x ) / $Size;
                // console.log(Math.random()*50+ -20) ;
                var top = (class_game.$divWidth*$y ) / $Size;
                // console.log("left&top",left,top);
                // var $div = $("<div style='width:"+$width+"rem;left:"+class_game.$divWidth*$x+"px;top:"+(class_game.$divHeight*$y)+"px;'><img src="+src+"></img></div>");
                //随机图片
                var imgSrcIndex = Math.floor(Math.random() * 2);  
                
                // 如果是xigua2.png图片，大小更大一点
                if(imgSrcIndex == 0){
                     $imgWidth = 100 
                }
                /*屏幕为768以上。西瓜大小为100*/
                if($("#xigua").width()>768){
                    $imgWidth = 100;
                }
                // 设置随机的宽度值 
                // $width = (Math.floor( $imgWidth +  ($imgWidth * Math.random())) / $Size);
                var  $width = (Math.floor( $imgWidth ) / $Size);

                // 生成西瓜
                var $div = $("<div class='xiaoxigua' style='width:"+$width+"rem;left:"+left+"rem;z-index:11;top:"+top+"rem;'><img ;  src="+src[imgSrcIndex]+"></img></div>");

                // 一维坐标的值-》对应ID 
                $div.attr("id", $y * class_game.$column + $x);
                // 随机旋转的角度
                $div.css({
                    transform:"rotate("+$rotate+"deg)"
                })
                // 添加到页面中
                $xiguaBox.append($div);
                 //   $div.attr("id", $y * this.class_game.$column + $x);//id
            }
          }
            // this.watermelonarrange();


        },
        showSource:function(){
            alert('click');
        },

        daxigua:function(){
            
        },
        /**
         * 打中猹的时候的出现的
         * @return {[type]} [description]
         */
        theWinning:function(){
            $("#chacha").tap(function(){
                // alert(this);
                alert("123123");
            })
        },

        toolShow:function(){

        },
        /**
         * 猹的随机跑位
         */
        
        ChaCha:function(){

            // "$column" : 5, //西瓜的排列的列
            //  "$row" : 3,  
          var $this = this; 
          var num = $this.class_game.$column * $this.class_game.$row;
          var xigualist = $("#xigua > .xiaoxigua");
          var length =  xigualist.length;
          var curId = null;
          var ChaCha = setInterval(function(){
              if($this.timerNumber == 0){
                  $(".cha").css({
                     display:"none",
                     transform:"translateY(100%)"
                  })
                   return clearInterval(ChaCha);
               }
              $(".cha").css({
                 display:"block",
                 transform:"translateY(100%)"
              })
              for(var i = 0 ;i <length-1 ; i ++) {
                  xigualist.css({
                     "z-index":"10"
                  })
              }

               var  randomId  = Math.ceil(Math.random()*length-1 );
               if(curId == randomId ){
                    randomId = curId = Math.ceil(Math.random()*length-1 );
               }
               curId = randomId;

               // alert(randomId);
               // 更新位置
               var xiguaDiv = $("#"+randomId+"");
               console.log("xiguaDiv",xiguaDiv);

                //console.log(xiguaDiv);
               // console.log()
               //获得定位
               //console.log(xiguaDiv);
               var randomPosLeft = xiguaDiv.css("left"),randomPosTop  = xiguaDiv.css("top");
               // randomPosWidth = xiguaDiv.css("width"),randomPosHeight = xiguaDiv.css("height");
              //  $(".cha").css({
              //    animation:"bearShow 2s"
              // })
                 
                xiguaDiv.css({
                    "z-index":14
                })
                
                console.log("id::::::",xiguaDiv,randomPosLeft,randomPosTop);
               // $("#chacha").css({
               //      left:randomPosLeft,
               //      top:(parseInt(randomPosTop)* $this.getFontSize() - xiguaDiv.height() / 1.5 )+ "px"
                   
               // })
               // 
               // 
              var topNum = 1.5;
              if(randomId == 3){
                  topNum = 0.5;
               }
                $("#chacha").css({
                    left:randomPosLeft,
                    top:(parseInt(randomPosTop) -  xiguaDiv.height() / topNum) + "px"
                   
               })
              // $(".cha").css({
              //    transform:"translateY(0%)"
              // }
              // 
            // 点不到的值  100 ->>500
            var speed = Math.ceil(Math.random()*5);
            var transformY = 100;
            var timer2 = setInterval(function(){
                transformY = transformY - 3;
                if(transformY <= 0){
                    clearInterval(timer2);
                }else{
                    $(".cha").css({
                        transform:"translateY("+transformY+"%)"
                    })
                }
                console.log(0);
            },speed)
            // console.log(1);
            
          },500);       
        },
        /**
         * 倒计时
         * @return {[type]} [description]
         */
        timer:function(){
            // alert('123');
            var $this = this;
            var timer = setInterval(function(){
                    $this.timerNumber = --$this.timerNumber;
                    console.log($this.timerNumber);
                    $(".timerNum").html("0"+$this.timerNumber + "S");
                    if($this.timerNumber == 0){
                        clearInterval(timer);
                    }
            },1000)
        },
        /**
         * 获得当前rem的font-size的大小
         * @return {[type]} [description]
         */
        getFontSize(){
            var clientWidth = $(document.body)[0].clientWidth;
            return 100 * (clientWidth / 740);
            
        }
        


    }
    var maincode = new mainCode();
    return mainCode
})($)

});
