
    var common  =  {
            //获取地址栏参数的值
            getQueryString: function(name) {
                var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)");
                var r = window.location.search.substr(1).match(reg);
                if(r != null) return unescape(r[2]);
                return null;
            },
            //横屏检测
            landscapeCheck: function() {
                if(window.orientation || window.orientation === 0) {
                    if(window.orientation !== 0) {
                        frameScript.showPop({
                            ele: document.getElementById("isLandscape")
                        });
                    } else {
                        frameScript.closePop({
                            ele: document.getElementById("isLandscape")
                        });
                    }
                }
            },
            /**
             * 显示隐藏
             * 
             * @param  {[type]}  ele    [description]
             * @param  {Boolean} isShow [description]
             * @return {Boolean}        [description]
             */
            isShowPop:function(ele,isShow){
                this.scrollEnable();
                if(isShow){
                    ele.addClass("webkitBox");

                    setTimeout(function() {
                    ele.addClass("show");
                    }, 1); 
                }
                else
                {   
                    console.log(ele.attr('class'));
                    ele.removeClass("show webkitBox");

                    setTimeout(function() {
                    ele.removeClass("webkitBox");
                    }, 1);   
                    
                }
                   
            },
            showPop: function(config) {
               
                this.scrollEnable();
                var shadeClose = config.shadeClose || false;
  
                config.ele.className = "webkitBox";
               
                setTimeout(function() {
                    config.ele.className = "webkitBox show";
                }, 2);
                if(shadeClose) {
                    config.ele.addEventListener("touchend", shadeCtrl, false);

                    function shadeCtrl() {
                        if(typeof config.closeCallBack === "function") {
                            config.closeCallBack();
                        }
                        config.ele.className = "webkitBox";
                        setTimeout(function() {
                            config.ele.className = "";
                            config.ele.removeEventListener("touchend", shadeCtrl, false);
                        }, 0);
                    }
                }
            },
            /* 关闭弹层
             * config.ele: HTML元素
             * config.closeCallBack: 成功关闭后的回调方法
             */
            closePop: function(config) {
                this.scrollDisable();
                if(typeof config.closeCallBack === "function") {
                    config.closeCallBack();
                }
                // config.ele.className = "webkitBox";
                setTimeout(function() {
                    config.ele.className = "";
                }, 1);
                if(event) {
                    event.preventDefault();
                    event.stopPropagation();
                }
            },
            //页面滚动开关
            scrollDisable: function() {
                document.addEventListener("touchmove", this.scrollEventHandle, false);
                document.addEventListener("scroll", this.scrollEventHandle, false);
            },
            scrollEnable: function() {
                document.removeEventListener("touchmove", this.scrollEventHandle, false);
                document.removeEventListener("scroll", this.scrollEventHandle, false);
            },
            scrollEventHandle: function() {
                event.preventDefault();
                return false;
            },
            setTitle: function(title) {
                document.title = title;
                // 判断是否为ios设备，ios设备需要通过加载iframe来刷新title
                if(navigator.userAgent.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/)) {
                    document.getElementById("iframeForSetTitle").src = '/favicon.ico?v=' + Math.random()
                }
            }
        }

    common.landscapeCheck();
    window.onorientationchange = common.landscapeCheck;





