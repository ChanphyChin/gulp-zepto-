var ajax = (function($){
    var www='';
    let path = window.location.pathname;
    path = path.replace('/', '');
    let length = path.indexOf('/');
    path = path.slice(0, length);
    var service = path ? '/' + path : '/yfcmcc-main-wxsite';
    
    var api = {
         getshare:www+service+'/yfcmcc/share_get',    //微信分享接口
         getXwactShareSign:www + service +'/session/js_api_sdk_sign_get' //获得数据
    }
    function getData(obj,callback) {
       var type = obj.type || 'GET',
       url = obj.url,
       data = obj.data || "",
       dataType =  obj.dataType || "",
       context = obj.context || $("body");
       $.ajax({
          type: type,
          url: url,
          data: {data:data },
          dataType: 'json',
          timeout: 300,
          context: context,
          success: function(data){
            callback(data)
          },
          error: function(xhr, type){
            alert('Ajax error!')
          }
        })
    }
    return {
        getData:getData,
        api : api
    }
    
})($)