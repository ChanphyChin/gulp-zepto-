var gulp = require('gulp'); //gulp
var $ = require('gulp-load-plugins')(); //可以省略引用
var open = require('open'); //自动打开
var babel = require('gulp-babel');


// 目录
var app = {
    srcPath: 'src/', //源代码
    devPath: 'build/', //开发目录
    prdPath: 'dist/' //生产
}

//模拟数据的json
gulp.task('json', function() {
    gulp.src(app.srcPath + 'data/**/*.json')
        .pipe(gulp.dest(app.devPath + 'data'))
        .pipe(gulp.dest(app.prdPath + 'data'))
        .pipe($.connect.reload());
});

//bower 指定下载的第三方的插件或库
gulp.task('lib', function() {
    gulp.src('lib/**/*.js')
        .pipe(gulp.dest(app.devPath + 'vendor'))
        .pipe(gulp.dest(app.prdPath + 'vendor'))
        .pipe($.connect.reload())
})

//打包html压缩
gulp.task('html', function() {
    gulp.src(app.srcPath + '**/*.html')
        .pipe(gulp.dest(app.devPath))
        .pipe($.htmlmin({
            collapseWhitespace: true, //去除空格
            removeComments: true, //去除注释
            minifyJS: true //压缩js
        }))
        .pipe(gulp.dest(app.prdPath))
        .pipe($.connect.reload())
})

//生成css样式，并压缩。加入私有前缀
gulp.task('css', function() {
    gulp.src(app.srcPath + 'style/*.css')
        .pipe($.autoprefixer())
        .pipe(gulp.dest(app.devPath + 'css'))
        .pipe($.cssnano())
        .pipe(gulp.dest(app.prdPath + 'css'))
        .pipe($.connect.reload())
})

//给css添加前缀
/*gulp.task('autoprefixer', function() {
    //src是告诉gulp数据的源头
    //拿到所有的css文件
    gulp.src(app.srcPath + 'style/*.css')
        .pipe($.autoprefixer()) //pipe拿到前面的数据
        .pipe($.cssnano())
        .pipe(gulp.dest(app.prdPath + 'css'))
});
*/
//.pipe($.concat('index.js'))
gulp.task('js', function() {
    gulp.src(app.srcPath + 'script/**/*.js')
        .pipe($.babel({
                 presets: ['es2015']
            }))
        .pipe(gulp.dest(app.devPath + 'js'))
        .pipe($.uglify())
        .pipe(gulp.dest(app.prdPath + 'js'))
        .pipe($.connect.reload());
})


gulp.task('image', function() {
    gulp.src(app.srcPath + 'image/**/*')
        .pipe(gulp.dest(app.devPath + 'image'))
        .pipe($.image())
        .pipe(gulp.dest(app.prdPath + 'image'))
        .pipe($.connect.reload());
})


gulp.task('less', function() {
    gulp.src(app.srcPath + 'style/index.less')
    .pipe($.less())
    .pipe($.autoprefixer()) //pipe拿到前面的数据
    .pipe(gulp.dest(app.devPath + 'css'))
    .pipe($.cssmin())
    .pipe(gulp.dest(app.prdPath + 'css'))
    .pipe($.connect.reload());
});


// 打包项目
gulp.task('build', ['image', 'js', 'css', 'less', 'lib', 'html'])
    //
gulp.task('clean', function() {
    gulp.src([app.devPath, app.prdPath])
        .pipe($.clean())
})



gulp.task('server', ['build'], function() {
    $.connect.server({
        root: app.devPath,
        livereload: true,
        port: 8008
    });

    open('http://localhost:8008');

    gulp.watch('lib/**/*', ['lib']);
    gulp.watch(app.srcPath + '**/*.html', ['html']);
    gulp.watch(app.srcPath + 'style/**/*.css', ['css']);
    gulp.watch(app.srcPath + 'style/**/*.less', ['less']);
    gulp.watch(app.srcPath + 'script/**/*.js', ['js']);

});

gulp.task('default', ['server']);
